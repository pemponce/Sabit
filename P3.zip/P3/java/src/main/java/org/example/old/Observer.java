package org.example.old;

interface Observer {
    void update (String news);
}